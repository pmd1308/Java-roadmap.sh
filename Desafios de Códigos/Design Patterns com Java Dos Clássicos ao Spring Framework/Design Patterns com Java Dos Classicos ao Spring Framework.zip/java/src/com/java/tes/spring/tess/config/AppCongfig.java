package com.spring.con.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.config.AbstractMongoClientConfiguration;
import com.mongodb.client.MongoClient;
import java.util.UUID;

@Configuration
public class AppCongfig extends AbstractMongoClientConfiguration {
    @Override
    protected String getDatabaseName() {
        return "Ficticio";
    }

    @Bean
    @Override
    public MongoClient mongoClient() {
        return MongoClients.create("mongodb://localhost:27017");
    }

    @Bean
    public String jwtSecret() {
        return UUID.randomUUID().toString().replace("-", "");
    } 
}