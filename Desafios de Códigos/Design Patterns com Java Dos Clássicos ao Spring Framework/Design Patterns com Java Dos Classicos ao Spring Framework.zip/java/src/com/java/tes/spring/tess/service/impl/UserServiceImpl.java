package com.spring.con.service.impl;

import com.spring.con.dto.UserDTO;
import com.spring.con.model.User;
import com.spring.con.repository.UserRepository;
import com.spring.con.service.UserService;
import com.spring.con.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    @Override
    public UserDTO registerUser(UserDTO userDTO) {
        String encodedPassword = bbCryptPasswordEncoder.encode(userDTO.getPassword());
        User user = new User(userDTO.getUsername(), encodedPassword, userDTO.getEmail());
        userRepository.save(user);
        return new UserDTO(user.getUsername(), user.getPassword(), user.getEmail());
    }

    @Override
    public UserDTO getUserByUsername(String username) {
        User user = userRepository.findByUsername(username)
               .orElseThrow(() -> new UsernameNotFoundException("User not found with username: " + username));
        return new UserDTO(user.getUsername(), user.getPassword(), user.getEmail());
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUsername(username)
               .orElseThrow(() -> new UsernameNotFoundException("User not found with username: " + username));
        return org.springframework.security.core.userdetails.User
        .withUsername(user.getUsername())
        .password(user.getPassword())
        .roles("USER")
        .build();
    }
    
}