package com.spring.con.service;

import com.spring.con.dto.UserDTO;
import org.springframework.security.core.userdetails.UserDetailsService;

public interface UserService extends UserDetailsService {
    UserDTO registerUser(UserDTO userDTO);
    String authenticateUser(UserDTO userDTO);
    UserDTO getUserByUsername(String username);
}
